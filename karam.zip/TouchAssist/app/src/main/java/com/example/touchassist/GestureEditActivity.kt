package com.example.touchassist

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** شاشة حفظ إيماءة جديدة (اسم + إعدادات) أو تعديل إيماءة موجودة. */
class GestureEditActivity : Activity() {

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL

        val id = intent.getStringExtra("id")
        val isNew = id == null
        val g: Gesture? = if (id != null) {
            Store.loadGestures(this).firstOrNull { it.id == id }
        } else {
            AssistService.pending
        }
        if (g == null) {
            finish()
            return
        }

        val defaultName = "إيماءة ${Store.loadGestures(this).size + 1}"

        if (isNew) {
            buildNameDialog(g, defaultName)
            return
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(16), dp(20), dp(8))

        root.addView(label(if (isNew) "اسم الإيماءة الجديدة" else "تعديل الإيماءة"))
        val nameEt = EditText(this)
        nameEt.setSingleLine(true)
        nameEt.hint = defaultName
        nameEt.setText(g.name)
        root.addView(nameEt, matchWrap())

        root.addView(label("طريقة التنفيذ"))
        val rg = RadioGroup(this)
        val r1 = RadioButton(this)
        r1.id = 1001
        r1.text = "في نفس المكان المسجّل (ماكرو)"
        val r2 = RadioButton(this)
        r2.id = 1002
        r2.text = "اختار المكان قبل التنفيذ (بتتنفّذ أول ما ترفع إصبعك)"
        val r3 = RadioButton(this)
        r3.id = 1003
        r3.text = "كورة ثابتة (زي ماكرو الآيفون): حرّكها وثبّتها، وتنفّذ بضغطة مطوّلة أو ضغطتين على الزر"
        rg.addView(r3)
        rg.addView(r2)
        rg.addView(r1)
        rg.check(
            when {
                isNew -> 1003
                g.armed -> 1003
                g.placeMode -> 1002
                else -> 1001
            }
        )
        root.addView(rg, matchWrap())

        val simCb = CheckBox(this)
        simCb.text = "شغّل كل اللمسات في نفس الوقت (زي iOS بالظبط). شيّل العلامة لو عايزها بنفس التوقيت اللي سجّلته"
        simCb.isChecked = if (isNew) true else g.simultaneous
        root.addView(simCb, matchWrap())

        val keepCb = CheckBox(this)
        keepCb.text = "احتفظ بالوقفات زي ما سجّلت (اضغط وانتظر ثم اسحب). لو مقفولة: الوقفات بتتقلّص والخط بيتنفّذ سريع"
        keepCb.isChecked = g.keepPauses
        root.addView(keepCb, matchWrap())

        root.addView(label("سرعة اللمس: مدة كل خط بالمللي ثانية (بتتطبق لو مدة السحب مقفولة. 0 = زي ما سجّلت)"))
        val strokeEt = numberField(g.strokeMs.toString(), false)
        root.addView(strokeEt, matchWrap())

        root.addView(label("إعدادات الكورة: بتتطبّق على أيقونة اللمس المساعد وهي ظاهرة، والكورة نفسها مبتاخدش لمس (اللمس بيوصل للتطبيق اللي تحتها). مش بتتأثر بإعدادات الهاتف"))

        root.addView(label("مدة الضغط المطوّل على الأيقونة وهي ظاهرة بالثواني (من 0 لـ 10)"))
        val longEt = numberField(String.format(java.util.Locale.US, "%.2f", g.ballLongMs / 1000f), true)
        root.addView(longEt, matchWrap())

        root.addView(label("مهلة الضغطتين على الأيقونة بالمللي ثانية (0 – 1000)"))
        val dblEt = numberField(g.ballDoubleMs.toString(), false)
        root.addView(dblEt, matchWrap())

        val tapCb = CheckBox(this)
        tapCb.text = "تفعيل مدة النقر: بتتطبّق على نقرات الإيماءة وأوامر tap المكتوبة على مكان الكورة"
        tapCb.isChecked = g.tapOn
        root.addView(tapCb, matchWrap())
        root.addView(label("مدة النقر بالمللي ثانية (0 – 1000)"))
        val tapEt = numberField(g.tapMs.toString(), false)
        root.addView(tapEt, matchWrap())

        val swCb = CheckBox(this)
        swCb.text = "تفعيل مدة السحب: بتتطبّق على خطوط الإيماءة وأوامر swipe المكتوبة على مكان الكورة"
        swCb.isChecked = g.swipeOn
        root.addView(swCb, matchWrap())
        root.addView(label("مدة السحب بالمللي ثانية (0 – 1000)"))
        val swEt = numberField(g.swipeMs.toString(), false)
        root.addView(swEt, matchWrap())

        root.addView(label("الأهداف: بتتنفّذ على مكان الكورة لما تعمل الحركة دي على أيقونة اللمس المساعد وهي ظاهرة. اختار إجراء جاهز أو اكتب هدف بنفسك (✍️). ضغطة واحدة على الأيقونة بتخفي الكورة، وضغطتين بتشغّل الهدف الرئيسي، والضغطة المطولة بتشغّل تسجيل الإيماءة (الخط اللي سجّلته) على مكان الكورة"))
        val ballMap = HashMap<String, String>(g.ballActions)
        val ballRows = listOf(
            "main" to "هدف الكورة الرئيسي (بيتنفّذ بضغطتين على الأيقونة)",
            "@sep" to "أهداف لمس المكان: بتتنفّذ لما تلمس مكان الكورة نفسه، ولمسك بيتمرّر للتطبيق اللي تحتها بإعدادات الكورة",
            "tap" to "عند النقر على المكان",
            "double" to "عند النقر مرتين على المكان",
            "long" to "عند الضغط المطوّل على المكان",
            "up" to "عند السحب لأعلى على المكان",
            "down" to "عند السحب لأسفل على المكان",
            "left" to "عند السحب لليسار على المكان",
            "right" to "عند السحب لليمين على المكان",
            "swipe" to "عند أي سحب على المكان"
        )
        for ((key, rowTitle) in ballRows) {
            if (key == "@sep") {
                root.addView(label(rowTitle))
                continue
            }
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.setPadding(0, dp(10), 0, dp(10))
            val l = TextView(this)
            l.text = rowTitle
            l.textSize = 14f
            val vv = TextView(this)
            vv.text = Actions.label(this, ballMap[key] ?: "none")
            vv.textSize = 13f
            vv.setTextColor(0xFF8E8E93.toInt())
            row.addView(l, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(vv)
            row.setOnClickListener {
                ActionPicker.show(this, rowTitle, true, ballMap[key] ?: "none") { picked ->
                    ballMap[key] = picked
                    vv.text = Actions.label(this, picked)
                }
            }
            root.addView(row, matchWrap())
        }

        root.addView(label("عدد التكرار (0 = بلا نهاية لحد ما توقفه)"))
        val repeatEt = numberField(g.repeat.toString(), false)
        root.addView(repeatEt, matchWrap())

        root.addView(label("التأخير بين كل تكرار (مللي ثانية)"))
        val delayEt = numberField(g.repeatDelay.toString(), false)
        root.addView(delayEt, matchWrap())

        root.addView(label("السرعة (1.0 = عادي، 2.0 = ضعف السرعة)"))
        val speedEt = numberField(g.speed.toString(), true)
        root.addView(speedEt, matchWrap())

        val info = TextView(this)
        info.textSize = 12f
        info.setTextColor(0xFF6B6B70.toInt())
        info.text = "${g.strokes.size} لمسة • ${g.totalDuration} ms"
        info.setPadding(0, dp(8), 0, dp(4))
        root.addView(info)

        val btns = LinearLayout(this)
        btns.orientation = LinearLayout.HORIZONTAL
        btns.gravity = Gravity.CENTER

        val save = Button(this)
        save.text = "حفظ"
        save.setOnClickListener {
            g.name = nameEt.text.toString().trim().ifEmpty { defaultName }
            g.placeMode = rg.checkedRadioButtonId == 1002
            g.armed = rg.checkedRadioButtonId == 1003
            g.simultaneous = simCb.isChecked
            g.keepPauses = keepCb.isChecked
            g.strokeMs = (strokeEt.text.toString().toIntOrNull() ?: 100).coerceIn(0, 5000)
            g.ballLongMs = ((longEt.text.toString().toFloatOrNull() ?: 0.5f).coerceIn(0f, 10f) * 1000f).toInt()
            g.ballDoubleMs = (dblEt.text.toString().toIntOrNull() ?: 300).coerceIn(0, 1000)
            g.tapOn = tapCb.isChecked
            g.tapMs = (tapEt.text.toString().toIntOrNull() ?: 50).coerceIn(0, 1000)
            g.swipeOn = swCb.isChecked
            g.swipeMs = (swEt.text.toString().toIntOrNull() ?: 100).coerceIn(0, 1000)
            g.ballActions.clear()
            for ((bk, bv) in ballMap) if (bv != "none") g.ballActions[bk] = bv
            g.repeat = (repeatEt.text.toString().toIntOrNull() ?: 1).coerceAtLeast(0)
            g.repeatDelay = (delayEt.text.toString().toLongOrNull() ?: 0L).coerceAtLeast(0L)
            g.speed = (speedEt.text.toString().toFloatOrNull() ?: 1f).coerceIn(0.1f, 10f)
            Store.upsert(this, g)
            if (isNew) AssistService.pending = null
            Toast.makeText(this, "اتحفظت: ${g.name}", Toast.LENGTH_SHORT).show()
            finish()
        }
        btns.addView(save)

        if (!isNew) {
            val del = Button(this)
            del.text = "حذف"
            del.setOnClickListener {
                AlertDialog.Builder(this)
                    .setMessage("تمسح الإيماءة \"${g.name}\"؟")
                    .setPositiveButton("امسح") { _, _ ->
                        Store.delete(this, g.id)
                        finish()
                    }
                    .setNegativeButton("لأ", null)
                    .show()
            }
            btns.addView(del)
        }

        val cancel = Button(this)
        cancel.text = "إلغاء"
        cancel.setOnClickListener {
            if (isNew) AssistService.pending = null
            finish()
        }
        btns.addView(cancel)
        root.addView(btns, matchWrap())

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    /** نافذة "إيماء جديد" زي iOS: اسم + إلغاء/حفظ. الإعدادات المتقدمة بتتعدّل بعدين من القايمة. */
    private fun buildNameDialog(g: Gesture, defaultName: String) {
        setFinishOnTouchOutside(false)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(18), dp(20), dp(6))

        val title = TextView(this)
        title.text = "إيماء جديد"
        title.textSize = 17f
        title.gravity = Gravity.CENTER
        title.setTypeface(title.typeface, android.graphics.Typeface.BOLD)
        root.addView(title, matchWrap())

        val et = EditText(this)
        et.setSingleLine(true)
        et.hint = "اسم الإيماء"
        et.textSize = 15f
        val lp = matchWrap()
        lp.topMargin = dp(14)
        root.addView(et, lp)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val blue = 0xFF007AFF.toInt()

        val cancel = TextView(this)
        cancel.text = "إلغاء"
        cancel.setTextColor(blue)
        cancel.textSize = 17f
        cancel.gravity = Gravity.CENTER
        cancel.setPadding(0, dp(14), 0, dp(14))
        cancel.setOnClickListener {
            AssistService.pending = null
            finish()
        }

        val save = TextView(this)
        save.text = "حفظ"
        save.setTextColor(blue)
        save.textSize = 17f
        save.gravity = Gravity.CENTER
        save.setTypeface(save.typeface, android.graphics.Typeface.BOLD)
        save.setPadding(0, dp(14), 0, dp(14))
        save.setOnClickListener {
            g.name = et.text.toString().trim().ifEmpty { defaultName }
            g.armed = true
            g.simultaneous = true
            Store.upsert(this, g)
            AssistService.pending = null
            Toast.makeText(this, "اتحفظت: ${g.name}", Toast.LENGTH_SHORT).show()
            finish()
        }

        row.addView(cancel, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(save, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val rlp = matchWrap()
        rlp.topMargin = dp(10)
        root.addView(row, rlp)
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun label(t: String): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 14f
        v.setPadding(0, dp(12), 0, dp(2))
        return v
    }

    private fun numberField(value: String, decimal: Boolean): EditText {
        val e = EditText(this)
        e.setSingleLine(true)
        e.inputType = InputType.TYPE_CLASS_NUMBER or
            (if (decimal) InputType.TYPE_NUMBER_FLAG_DECIMAL else 0)
        e.setText(value)
        return e
    }
}
